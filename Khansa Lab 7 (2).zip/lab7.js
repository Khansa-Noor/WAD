//Task 1
var heading = document.getElementById("heading");
heading.innerHTML += " - Khansa Noor (54039)";
//Task 2
var containers = document.getElementsByClassName("Container");
var texts = ["Khansa Noor", "BSCS-4", "Riphah International University"];
for (var i = 0; i < containers.length; i++) {
    containers[i].innerHTML = texts[i];
}