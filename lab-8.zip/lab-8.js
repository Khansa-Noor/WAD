
  // task-1 --------------------------------- 
  function changeClass() {
    // Get the element by ID
    var element = document.getElementById("myPara");

    // Access and log the current class
    console.log("Old class:", element.className);

    // Set a new class name
    element.className = "newClass";

    // Log the updated class
    console.log("New class:", element.className);
  }

  // task-2  --------------------------------- 

// 1. Create the button element
var button = document.createElement("button");

// 2. Set ID and text content
button.id = "logIn";
button.textContent = "Log In";

// 3. Style the button (background and text color)
button.style.backgroundColor = "#4CAF50"; // green background
button.style.color = "white";            // white text
button.style.padding = "10px 20px";
button.style.border = "none";

// 4. Insert it before the <body> tag
document.documentElement.insertBefore(button, document.body);

// task-3 --------------------------------- 
function addNewStyle() {
    // Get the <p> element
    var para = document.getElementById("myParagraph");
  
    // Append the new class
    para.classList.add("extra-style");
  }
  